#!/bin/bash
cd "`dirname "$0"`"
./xnbcli unpack ./packed ./unpacked
read -p "Press enter to continue"
